---
title: "Layout: Header Overlay with Background Fill"
header:
  overlay_color: "#333"
categories:
  - Layout
  - Uncategorized
tags:
  - edge case
  - image
  - layout
---

This post should display a **header with a solid background color**, if the theme supports it.

Non-square images can provide some unique styling issues.

This post tests overlay headers.